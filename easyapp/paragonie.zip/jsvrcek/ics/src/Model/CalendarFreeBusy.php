<?php

namespace Jsvrcek\ICS\Model;

class CalendarFreeBusy
{
}
