<?php

namespace Jsvrcek\ICS\Exception;

class CalendarEventException extends CalendarException
{
}
